$(document).ready(function(){
	$(".right_video").fitVids();
	
	 $('#simple-menu').sidr();
});
